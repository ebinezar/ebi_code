When a user types in a @gmail.com into the user name field the [Log in with Google] button shows up,
clicking it allows the user to authenticate with Google OpenID.

NOTES:
- Registering the user automatically is a sensitive area. It's disabled by default

TODO:
- When a user has a @gmail.com, should logging in be done *only* through this account?
- Modify the confirmation message when the user is @gmail.com
- See also TODOs in the code