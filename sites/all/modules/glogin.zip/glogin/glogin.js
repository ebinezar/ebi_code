/**
 * Briefly: it shows up the Google login submit button under the user name when
 * it is appropriate. Then deals with the [ENTER] button, since we have two
 * submit buttons the user expects that pressing [ENTER] in the password field
 * will authenticate with the website, while pressing the button in the login name
 * (if the button is there) field will authenticate with Google.
 **/

Drupal.behaviors.glogin = function (context) {
  // User name field
  var loginNameField = $('#user-login #edit-name');
  var loginNameFieldWrapper = $('#user-login #edit-name-wrapper');

  // Google submit. Move to the appropriate place
  var googleSubmitButton = $('#user-login #edit-google')
    .remove()
    .clone()
    .insertAfter(loginNameFieldWrapper);

  // Jump to this button only after the normal submit button
  googleSubmitButton.attr('tabindex', 4);

  // Remove the button initially
  if(!testGoogleAccount(loginNameField.attr('value'))) {
    googleSubmitButton.remove();
  }

  // Whenever I press [ENTER] in the password field submit the form with normal submit instead of Google
  $('#user-login #edit-pass:not(.glogin-processed)', context)
    .addClass('glogin-processed')
    .keydown(function submitNonGoogle(event) {
        var key = (event)? event.which: event.keyCode;
        if (key == 13) {
          googleSubmitButton.remove();
          $('#user-login').submit();
        }
    });

  // Show the Google submit button whenever the user name is a GMail
  $('#user-login #edit-name:not(.glogin-processed)', context)
    .addClass('glogin-processed')
    .keyup(detectGoogleAccount).blur(detectGoogleAccount);

  // See if the user name is a Google account
  function detectGoogleAccount() {
      if(testGoogleAccount(loginNameField.attr('value'))) {
        googleSubmitButton.insertAfter(loginNameFieldWrapper);
      } else {
        googleSubmitButton.remove();
      }
  }
  
  // Check if the value is a GMail
  function testGoogleAccount(value) {
    value = value.toLowerCase();
    if(value.indexOf('@google.com') > 0 || value.indexOf('@gmail.com') > 0) {
      return true;
    } else {
      return false;
    }
  }
}


